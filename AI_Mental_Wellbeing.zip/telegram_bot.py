#!/usr/bin/env python3
"""
Telegram AI Mental Wellbeing Bot

A Telegram bot that provides mental health support,
emotional guidance, and wellbeing resources.
"""

import os
import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv
import openai
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=getattr(logging, os.getenv('LOG_LEVEL', 'INFO')),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class MentalWellbeingBot:
    """
    Telegram bot for AI Mental Wellbeing support.
    """
    
    def __init__(self):
        """Initialize the bot with OpenAI client and configuration."""
        self.openai_client = openai.OpenAI(
            api_key=os.getenv('OPENAI_API_KEY')
        )
        self.model = os.getenv('DEFAULT_MODEL', 'gpt-3.5-turbo')
        self.max_tokens = int(os.getenv('MAX_TOKENS', '1000'))
        self.temperature = float(os.getenv('TEMPERATURE', '0.7'))
        
        # System prompt for mental wellbeing support
        self.system_prompt = """
        You are a compassionate AI mental wellbeing agent. Your role is to:
        
        1. Provide emotional support and active listening
        2. Offer evidence-based coping strategies
        3. Suggest mindfulness and relaxation techniques
        4. Help users identify and express their emotions
        5. Provide resources for professional help when appropriate
        6. Maintain a warm, non-judgmental, and supportive tone
        
        Important guidelines:
        - Never provide medical diagnosis or treatment
        - Always encourage professional help for serious mental health concerns
        - Focus on emotional support and practical coping strategies
        - Be empathetic and validate the user's feelings
        - Keep responses concise but meaningful (under 2000 characters for Telegram)
        - Ask follow-up questions to better understand the user's needs
        
        If a user expresses thoughts of self-harm or suicide, immediately:
        1. Take their concerns seriously
        2. Encourage them to contact emergency services or a crisis hotline
        3. Provide crisis resources
        """
        
        # Store conversation history per user
        self.user_conversations = {}
        
    def get_user_history(self, user_id: int) -> List[Dict]:
        """Get conversation history for a specific user."""
        if user_id not in self.user_conversations:
            self.user_conversations[user_id] = []
        return self.user_conversations[user_id]
    
    def add_to_history(self, user_id: int, role: str, content: str):
        """Add a message to user's conversation history."""
        history = self.get_user_history(user_id)
        history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        # Keep only last 10 messages to manage memory
        if len(history) > 10:
            history.pop(0)
    
    async def get_ai_response(self, user_id: int, user_message: str) -> str:
        """
        Generate a response to the user's message.
        
        Args:
            user_id: Telegram user ID
            user_message: The user's input message
            
        Returns:
            AI agent's response
        """
        try:
            # Add user message to history
            self.add_to_history(user_id, "user", user_message)
            
            # Prepare messages for OpenAI API
            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend(self.get_user_history(user_id))
            
            # Call OpenAI API
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            ai_response = response.choices[0].message.content
            
            # Add AI response to history
            self.add_to_history(user_id, "assistant", ai_response)
            
            logger.info(f"Generated response for user {user_id}: {user_message[:50]}...")
            return ai_response
            
        except Exception as e:
            logger.error(f"Error generating response for user {user_id}: {str(e)}")
            return "I apologize, but I'm experiencing some technical difficulties. Please try again in a moment, or consider reaching out to a mental health professional if you need immediate support."
    
    def get_coping_strategies(self, emotion: str) -> List[str]:
        """Provide coping strategies for specific emotions."""
        strategies = {
            "anxiety": [
                "Practice deep breathing exercises (4-7-8 technique)",
                "Try progressive muscle relaxation",
                "Use grounding techniques (5-4-3-2-1 method)",
                "Engage in gentle physical activity",
                "Practice mindfulness meditation"
            ],
            "sadness": [
                "Allow yourself to feel and express your emotions",
                "Connect with supportive friends or family",
                "Engage in activities you used to enjoy",
                "Practice self-compassion and self-care",
                "Consider journaling your thoughts and feelings"
            ],
            "anger": [
                "Take a break and step away from the situation",
                "Practice deep breathing or counting to 10",
                "Engage in physical exercise to release tension",
                "Use 'I' statements to express your feelings",
                "Try relaxation techniques like meditation"
            ],
            "stress": [
                "Break tasks into smaller, manageable steps",
                "Practice time management and prioritization",
                "Engage in regular physical exercise",
                "Maintain a healthy sleep schedule",
                "Practice relaxation techniques"
            ]
        }
        
        return strategies.get(emotion.lower(), [
            "Practice deep breathing exercises",
            "Engage in mindfulness or meditation",
            "Connect with supportive people",
            "Engage in physical activity",
            "Practice self-care activities"
        ])
    
    def get_crisis_resources(self) -> Dict[str, str]:
        """Provide crisis resources and emergency contacts."""
        return {
            "National Suicide Prevention Lifeline": "988",
            "Crisis Text Line": "Text HOME to 741741",
            "National Alliance on Mental Illness (NAMI)": "1-800-950-NAMI (6264)",
            "Emergency Services": "911",
            "SAMHSA National Helpline": "1-800-662-4357"
        }
    
    def clear_user_conversation(self, user_id: int):
        """Clear conversation history for a specific user."""
        if user_id in self.user_conversations:
            del self.user_conversations[user_id]
        logger.info(f"Conversation history cleared for user {user_id}")

# Initialize the bot
bot = MentalWellbeingBot()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    welcome_message = """
🧠 *Welcome to AI Mental Wellbeing Bot*

I'm here to provide emotional support and mental wellbeing guidance. I can help you with:

• Emotional support and active listening
• Coping strategies for different emotions
• Mindfulness and relaxation techniques
• Crisis resources when needed

*Important:* I'm a supportive tool and don't replace professional mental health care. For serious concerns, please seek professional help.

Use /help to see all available commands.
"""
    
    keyboard = [
        [InlineKeyboardButton("💬 Start Chat", callback_data="start_chat")],
        [InlineKeyboardButton("📚 Coping Strategies", callback_data="coping_strategies")],
        [InlineKeyboardButton("🚨 Crisis Resources", callback_data="crisis_resources")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(welcome_message, parse_mode='Markdown', reply_markup=reply_markup)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command."""
    help_text = """
*Available Commands:*

/start - Welcome message and main menu
/help - Show this help message
/clear - Clear your conversation history
/strategies - Get coping strategies for emotions
/crisis - Show crisis resources and emergency contacts

*How to use:*
• Simply type your message to chat with me
• Use the buttons for quick access to resources
• I'll remember our conversation during this session

*Remember:* If you're in crisis, please contact emergency services immediately.
"""
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def clear_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /clear command."""
    user_id = update.effective_user.id
    bot.clear_user_conversation(user_id)
    await update.message.reply_text("✅ Your conversation history has been cleared.")

async def strategies_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /strategies command."""
    keyboard = [
        [InlineKeyboardButton("😰 Anxiety", callback_data="strategy_anxiety")],
        [InlineKeyboardButton("😢 Sadness", callback_data="strategy_sadness")],
        [InlineKeyboardButton("😠 Anger", callback_data="strategy_anger")],
        [InlineKeyboardButton("😫 Stress", callback_data="strategy_stress")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Choose an emotion to get coping strategies:",
        reply_markup=reply_markup
    )

async def crisis_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /crisis command."""
    resources = bot.get_crisis_resources()
    crisis_text = "🚨 *Crisis Resources & Emergency Contacts:*\n\n"
    
    for name, contact in resources.items():
        crisis_text += f"*{name}:* {contact}\n"
    
    crisis_text += "\n*If you're in immediate danger, call 911 or your local emergency number.*"
    
    await update.message.reply_text(crisis_text, parse_mode='Markdown')

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle regular text messages."""
    user_id = update.effective_user.id
    user_message = update.message.text
    
    # Show typing indicator
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")
    
    # Get AI response
    ai_response = await bot.get_ai_response(user_id, user_message)
    
    # Send response
    await update.message.reply_text(ai_response)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks."""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    user_id = update.effective_user.id
    
    if data == "start_chat":
        await query.edit_message_text(
            "💬 *Chat Started*\n\nI'm here to listen and support you. Just type your message and I'll respond with care and understanding.\n\n*Remember:* I'm not a replacement for professional mental health care.",
            parse_mode='Markdown'
        )
    
    elif data == "coping_strategies":
        keyboard = [
            [InlineKeyboardButton("😰 Anxiety", callback_data="strategy_anxiety")],
            [InlineKeyboardButton("😢 Sadness", callback_data="strategy_sadness")],
            [InlineKeyboardButton("😠 Anger", callback_data="strategy_anger")],
            [InlineKeyboardButton("😫 Stress", callback_data="strategy_stress")],
            [InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "Choose an emotion to get coping strategies:",
            reply_markup=reply_markup
        )
    
    elif data == "crisis_resources":
        resources = bot.get_crisis_resources()
        crisis_text = "🚨 *Crisis Resources & Emergency Contacts:*\n\n"
        
        for name, contact in resources.items():
            crisis_text += f"*{name}:* {contact}\n"
        
        crisis_text += "\n*If you're in immediate danger, call 911 or your local emergency number.*"
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(crisis_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    elif data == "help":
        help_text = """
*Available Commands:*

/start - Welcome message and main menu
/help - Show this help message
/clear - Clear your conversation history
/strategies - Get coping strategies for emotions
/crisis - Show crisis resources and emergency contacts

*How to use:*
• Simply type your message to chat with me
• Use the buttons for quick access to resources
• I'll remember our conversation during this session

*Remember:* If you're in crisis, please contact emergency services immediately.
"""
        keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(help_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    elif data.startswith("strategy_"):
        emotion = data.replace("strategy_", "")
        strategies = bot.get_coping_strategies(emotion)
        
        strategy_text = f"*Coping Strategies for {emotion.title()}:*\n\n"
        for i, strategy in enumerate(strategies, 1):
            strategy_text += f"{i}. {strategy}\n"
        
        keyboard = [
            [InlineKeyboardButton("🔙 Back to Strategies", callback_data="coping_strategies")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(strategy_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    elif data == "main_menu":
        welcome_message = """
🧠 *AI Mental Wellbeing Bot*

I'm here to provide emotional support and mental wellbeing guidance.

Use the buttons below or type a message to start chatting.
"""
        
        keyboard = [
            [InlineKeyboardButton("💬 Start Chat", callback_data="start_chat")],
            [InlineKeyboardButton("📚 Coping Strategies", callback_data="coping_strategies")],
            [InlineKeyboardButton("🚨 Crisis Resources", callback_data="crisis_resources")],
            [InlineKeyboardButton("ℹ️ Help", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(welcome_message, parse_mode='Markdown', reply_markup=reply_markup)

def main():
    """Main function to run the bot."""
    # Check if required environment variables are set
    telegram_token = os.getenv('TELEGRAM_BOT_TOKEN')
    openai_key = os.getenv('OPENAI_API_KEY')
    
    if not telegram_token:
        logger.error("TELEGRAM_BOT_TOKEN not found in environment variables")
        print("❌ Error: TELEGRAM_BOT_TOKEN not found in .env file")
        return
    
    if not openai_key:
        logger.error("OPENAI_API_KEY not found in environment variables")
        print("❌ Error: OPENAI_API_KEY not found in .env file")
        return
    
    # Create application
    application = Application.builder().token(telegram_token).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("clear", clear_command))
    application.add_handler(CommandHandler("strategies", strategies_command))
    application.add_handler(CommandHandler("crisis", crisis_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(CallbackQueryHandler(handle_callback))
    
    # Start the bot
    logger.info("Starting AI Mental Wellbeing Bot...")
    print("🤖 AI Mental Wellbeing Bot is starting...")
    print("✅ Bot is running! Press Ctrl+C to stop.")
    
    application.run_polling()

if __name__ == "__main__":
    main()
