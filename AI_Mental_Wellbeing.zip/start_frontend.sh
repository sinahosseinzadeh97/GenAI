#!/bin/bash
# Start React frontend

echo "🌐 Starting AI Mental Wellbeing Frontend..."
cd web
npm run dev
