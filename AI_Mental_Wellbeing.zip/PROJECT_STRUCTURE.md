# 📁 Project Structure

```
AI_Mental_Wellbeing/
├── README.md                          # Main project documentation
├── PROJECT_STRUCTURE.md              # This file - project structure overview
├── setup.py                          # Setup script for easy installation
├── .gitignore                        # Git ignore rules
├── env.example                       # Environment variables template
├── requirements.txt                  # Python dependencies
├── requirements_api.txt              # Additional API dependencies
│
├── ai_mental_wellbeing_agent.py     # Main Streamlit web application
├── telegram_bot.py                   # Telegram bot implementation
├── telegram_bot_api.py              # Telegram bot API utilities
├── telegram_bot_setup.md            # Telegram bot setup guide
│
├── start_backend.sh                  # Backend startup script
├── start_frontend.sh                 # Frontend startup script
├── start_telegram.sh                 # Telegram bot startup script
│
├── backend/                          # FastAPI backend
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py                   # FastAPI application entry point
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   └── schemas.py            # Pydantic models
│   │   ├── services/
│   │   │   ├── __init__.py
│   │   │   └── ai_service.py         # AI service implementation
│   │   └── api/
│   │       ├── __init__.py
│   │       └── v1/
│   │           ├── __init__.py
│   │           └── endpoints.py      # API endpoints
│   ├── requirements.txt              # Backend dependencies
│   └── tests/                        # Backend tests
│       ├── test_ai_service.py
│       └── test_endpoints.py
│
└── web/                              # React frontend
    ├── package.json                  # Node.js dependencies
    ├── vite.config.ts               # Vite configuration
    ├── tsconfig.json                # TypeScript configuration
    ├── eslint.config.js             # ESLint configuration
    ├── public/
    │   └── vite.svg                 # Public assets
    ├── src/
    │   ├── main.tsx                 # React entry point
    │   ├── App.tsx                  # Main App component
    │   ├── App.css                  # App styles
    │   ├── index.css                # Global styles
    │   ├── components/
    │   │   ├── Layout.tsx           # Layout component
    │   │   └── ThemeToggle.tsx      # Theme toggle component
    │   ├── pages/
    │   │   ├── About.tsx            # About page
    │   │   ├── Chat.tsx             # Chat interface
    │   │   ├── CrisisResources.tsx  # Crisis resources page
    │   │   └── Strategies.tsx       # Coping strategies page
    │   ├── services/
    │   │   └── api.ts               # API service functions
    │   └── types/
    │       └── api.ts               # TypeScript type definitions
    └── dist/                         # Built frontend (generated)
        ├── index.html
        └── assets/
```

## 🚀 Quick Start Commands

### Setup
```bash
python setup.py
```

### Web Interface (Streamlit)
```bash
streamlit run ai_mental_wellbeing_agent.py
```

### Telegram Bot
```bash
python telegram_bot.py
```

### Backend API
```bash
cd backend && python -m uvicorn app.main:app --reload
```

### Frontend (React)
```bash
cd web && npm run dev
```

### All Services
```bash
# Terminal 1: Backend
./start_backend.sh

# Terminal 2: Frontend
./start_frontend.sh

# Terminal 3: Telegram Bot
./start_telegram.sh
```

## 🔧 Configuration

1. Copy `env.example` to `.env`
2. Add your OpenAI API key
3. Add your Telegram bot token (optional)
4. Configure other settings as needed

## 📱 Features by Component

### Streamlit App (`ai_mental_wellbeing_agent.py`)
- Interactive chat interface
- Sidebar with resources
- Conversation history
- Real-time AI responses

### Telegram Bot (`telegram_bot.py`)
- Command-based interactions
- Inline keyboard navigation
- Per-user conversation memory
- Mobile-optimized interface

### Backend API (`backend/`)
- RESTful API endpoints
- AI service integration
- Data validation with Pydantic
- CORS support for frontend

### Frontend (`web/`)
- Modern React application
- Material-UI components
- Responsive design
- Real-time chat interface
