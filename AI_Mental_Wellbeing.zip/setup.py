#!/usr/bin/env python3
"""
Setup script for AI Mental Wellbeing Agent
"""

import os
import sys
import subprocess
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors."""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e.stderr}")
        return False

def main():
    """Main setup function."""
    print("🧠 AI Mental Wellbeing Agent Setup")
    print("=" * 40)
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        sys.exit(1)
    
    print(f"✅ Python {sys.version.split()[0]} detected")
    
    # Install Python dependencies
    if not run_command("pip install -r requirements.txt", "Installing Python dependencies"):
        print("⚠️  Failed to install some dependencies. Please check requirements.txt")
    
    # Install API dependencies if backend exists
    if Path("backend/requirements.txt").exists():
        if not run_command("pip install -r backend/requirements.txt", "Installing backend dependencies"):
            print("⚠️  Failed to install backend dependencies")
    
    # Install Node.js dependencies if web exists
    if Path("web/package.json").exists():
        if not run_command("cd web && npm install", "Installing Node.js dependencies"):
            print("⚠️  Failed to install Node.js dependencies")
    
    # Create .env file if it doesn't exist
    if not Path(".env").exists():
        if Path("env.example").exists():
            run_command("cp env.example .env", "Creating .env file from template")
            print("📝 Please edit .env file with your API keys")
        else:
            print("📝 Please create a .env file with your API keys")
    
    print("\n🎉 Setup completed!")
    print("\nNext steps:")
    print("1. Edit .env file with your OpenAI API key and Telegram bot token")
    print("2. Run 'streamlit run ai_mental_wellbeing_agent.py' for web interface")
    print("3. Run 'python telegram_bot.py' for Telegram bot")
    print("4. Run 'cd web && npm run dev' for React frontend")

if __name__ == "__main__":
    main()
