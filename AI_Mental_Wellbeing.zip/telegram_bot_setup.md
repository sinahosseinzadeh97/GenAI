# Telegram Bot Setup Guide

## 🤖 Creating Your Telegram Bot

### Step 1: Create a Bot with BotFather

1. Open Telegram and search for `@BotFather`
2. Start a chat with BotFather
3. Send `/newbot` command
4. Choose a name for your bot (e.g., "AI Mental Wellbeing Bot")
5. Choose a username for your bot (must end with 'bot', e.g., "mental_wellbeing_bot")
6. BotFather will give you a **Bot Token** - save this!

### Step 2: Configure Environment Variables

1. Open your `.env` file
2. Replace `your_telegram_bot_token_here` with your actual bot token:
   ```
   TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
   ```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Run the Bot

```bash
python telegram_bot.py
```

## 🚀 Bot Features

### Commands Available:
- `/start` - Welcome message and main menu
- `/help` - Show help information
- `/clear` - Clear conversation history
- `/strategies` - Get coping strategies for emotions
- `/crisis` - Show crisis resources

### Interactive Features:
- **Chat Interface**: Direct conversation with AI
- **Coping Strategies**: Emotion-specific strategies
- **Crisis Resources**: Emergency contacts and helplines
- **Conversation Memory**: Remembers chat during session
- **Inline Buttons**: Easy navigation and quick access

## 🔧 Bot Configuration

### Optional Bot Settings (via BotFather):
- `/setdescription` - Set bot description
- `/setabouttext` - Set about text
- `/setuserpic` - Set bot profile picture
- `/setcommands` - Set command list

### Example Commands Setup:
```
start - Start chatting with the AI mental wellbeing bot
help - Show help information and available commands
clear - Clear your conversation history
strategies - Get coping strategies for different emotions
crisis - Show crisis resources and emergency contacts
```

## 🛡️ Safety Features

- **Crisis Detection**: Bot recognizes crisis situations
- **Professional Resources**: Provides emergency contacts
- **Disclaimers**: Clear about limitations
- **Privacy**: No permanent data storage
- **Session-based**: Conversations cleared when bot restarts

## 📱 Usage

1. Users find your bot on Telegram
2. Send `/start` to begin
3. Use buttons or type messages to interact
4. Bot provides emotional support and resources
5. All conversations are private and secure

## 🔍 Troubleshooting

### Common Issues:
- **Bot not responding**: Check if token is correct
- **Import errors**: Run `pip install -r requirements.txt`
- **API errors**: Verify OpenAI API key is set
- **Permission errors**: Ensure bot has necessary permissions

### Logs:
The bot logs all activities. Check console output for debugging information.

## 📞 Support

If you need help setting up the bot, check:
1. BotFather documentation
2. python-telegram-bot documentation
3. OpenAI API documentation

Remember: This bot is for supportive purposes only and doesn't replace professional mental health care.
