# 🧠 AI Mental Wellbeing Agent

A comprehensive AI-powered mental health support system that provides emotional guidance, coping strategies, and wellbeing resources through both a web interface and Telegram bot.

## 🌟 Features

### Core Functionality
- **Emotional Support**: AI-powered conversational agent for mental wellbeing
- **Coping Strategies**: Evidence-based techniques for anxiety, sadness, anger, and stress
- **Crisis Resources**: Emergency contacts and mental health helplines
- **Multi-Platform Access**: Web interface (Streamlit) and Telegram bot
- **Conversation Memory**: Contextual chat history for personalized support
- **Safety Features**: Crisis detection and professional resource recommendations

### Web Interface (Streamlit)
- Interactive chat interface with real-time AI responses
- Sidebar with quick access to coping strategies and crisis resources
- Conversation history display
- Clean, user-friendly design

### Telegram Bot
- Full-featured bot with inline keyboard navigation
- Command-based interactions (`/start`, `/help`, `/clear`, etc.)
- Per-user conversation memory
- Mobile-optimized interface

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- OpenAI API key
- Telegram Bot Token (for bot functionality)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd AI_Mental_Wellbeing
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables**
   Create a `.env` file in the project root:
   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
   DEFAULT_MODEL=gpt-3.5-turbo
   MAX_TOKENS=1000
   TEMPERATURE=0.7
   LOG_LEVEL=INFO
   ```

### Running the Applications

#### Web Interface
```bash
streamlit run ai_mental_wellbeing_agent.py
```
Access the web interface at `http://localhost:8501`

#### Telegram Bot
```bash
python telegram_bot.py
```

## 📱 Telegram Bot Setup

### Creating a Bot
1. Open Telegram and search for `@BotFather`
2. Send `/newbot` command
3. Choose a name and username for your bot
4. Save the provided Bot Token
5. Add the token to your `.env` file

### Bot Commands
- `/start` - Welcome message and main menu
- `/help` - Show help information
- `/clear` - Clear conversation history
- `/strategies` - Get coping strategies for emotions
- `/crisis` - Show crisis resources

## 🛠️ Technical Details

### Architecture
- **AI Agent**: OpenAI GPT integration for natural language processing
- **Web Interface**: Streamlit for interactive web application
- **Telegram Bot**: python-telegram-bot library for bot functionality
- **Environment Management**: python-dotenv for configuration

### Key Components

#### MentalWellbeingAgent Class
- OpenAI API integration
- Conversation history management
- Coping strategies database
- Crisis resources management
- Response generation with safety guidelines

#### Safety Features
- Crisis detection and response
- Professional resource recommendations
- Clear disclaimers about limitations
- No permanent data storage
- Session-based conversations

### Dependencies
- `openai>=1.3.0` - OpenAI API client
- `streamlit>=1.28.0` - Web interface framework
- `python-telegram-bot>=20.0` - Telegram bot library
- `python-dotenv>=1.0.0` - Environment variable management
- `pandas>=2.0.0` - Data manipulation
- `numpy>=1.24.0` - Numerical computing
- `requests>=2.31.0` - HTTP requests

## 🎯 Usage Examples

### Web Interface
1. Open the Streamlit app
2. Type your message in the chat input
3. Use sidebar buttons for quick access to resources
4. View conversation history in real-time

### Telegram Bot
1. Start a chat with your bot
2. Send `/start` to see the main menu
3. Use inline buttons or type messages directly
4. Access coping strategies and crisis resources

## 🛡️ Safety and Ethics

### Important Disclaimers
- **Not a replacement for professional mental health care**
- **For crisis situations, contact emergency services immediately**
- **No medical diagnosis or treatment provided**
- **Focus on emotional support and practical coping strategies**

### Crisis Resources Included
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- National Alliance on Mental Illness (NAMI): 1-800-950-NAMI
- Emergency Services: 911
- SAMHSA National Helpline: 1-800-662-4357

## 🔧 Configuration

### Environment Variables
- `OPENAI_API_KEY` - Required for AI functionality
- `TELEGRAM_BOT_TOKEN` - Required for bot functionality
- `DEFAULT_MODEL` - OpenAI model (default: gpt-3.5-turbo)
- `MAX_TOKENS` - Maximum response length (default: 1000)
- `TEMPERATURE` - Response creativity (default: 0.7)
- `LOG_LEVEL` - Logging level (default: INFO)

### Customization
- Modify coping strategies in the `get_coping_strategies()` method
- Update crisis resources in the `get_crisis_resources()` method
- Adjust system prompts for different AI behavior
- Customize UI elements in Streamlit interface

## 🐛 Troubleshooting

### Common Issues
- **Bot not responding**: Check Telegram token and API key
- **Import errors**: Ensure all dependencies are installed
- **API errors**: Verify OpenAI API key is valid and has credits
- **Permission errors**: Check bot permissions in Telegram

### Logs
Both applications provide detailed logging for debugging:
- Console output for real-time monitoring
- Structured logging with timestamps
- Error tracking and reporting

## 📈 Future Enhancements

- Multi-language support
- Voice message processing
- Integration with additional mental health APIs
- Analytics and usage tracking
- Mobile app development
- Advanced conversation analytics

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is for educational and supportive purposes. Please ensure compliance with OpenAI's usage policies and local regulations regarding mental health services.

## 📞 Support

For technical support or questions:
- Check the troubleshooting section
- Review the Telegram bot setup guide
- Consult OpenAI and python-telegram-bot documentation

---

**Remember**: This AI agent is designed to provide supportive conversation and resources, but it is not a replacement for professional mental health care. Always seek professional help for serious mental health concerns.
