export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
}

export interface ChatRequest {
  message: string;
  session_id?: string;
  user_id?: string;
}

export interface ChatResponse {
  response: string;
  session_id: string;
  crisis_detected: boolean;
  disclaimer: string;
}

export interface CopingStrategyRequest {
  emotion: string;
}

export interface CopingStrategyResponse {
  emotion: string;
  strategies: string[];
  disclaimer: string;
}

export interface CrisisResource {
  name: string;
  contact: string;
}

export interface CrisisResponse {
  resources: CrisisResource[];
  disclaimer: string;
}

export interface HealthResponse {
  status: string;
  timestamp: string;
  version: string;
}
