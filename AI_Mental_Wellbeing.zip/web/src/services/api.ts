import axios from 'axios';
import type {
  ChatRequest,
  ChatResponse,
  CopingStrategyRequest,
  CopingStrategyResponse,
  CrisisResponse,
  HealthResponse,
} from '../types/api';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor for logging
api.interceptors.request.use(
  (config) => {
    console.log(`Making ${config.method?.toUpperCase()} request to ${config.url}`);
    return config;
  },
  (error) => {
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('Response error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

export const apiService = {
  // Health check
  async getHealth(): Promise<HealthResponse> {
    const response = await api.get('/api/v1/health');
    return response.data;
  },

  // Chat
  async sendMessage(request: ChatRequest): Promise<ChatResponse> {
    const response = await api.post('/api/v1/chat', request);
    return response.data;
  },

  // Coping strategies
  async getCopingStrategies(request: CopingStrategyRequest): Promise<CopingStrategyResponse> {
    const response = await api.post('/api/v1/strategies', request);
    return response.data;
  },

  // Crisis resources
  async getCrisisResources(): Promise<CrisisResponse> {
    const response = await api.get('/api/v1/crisis');
    return response.data;
  },

  // Clear conversation
  async clearConversation(sessionId: string): Promise<void> {
    await api.delete(`/api/v1/chat/${sessionId}`);
  },
};

export default apiService;
