import React, { useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Alert,
  Chip,
  CircularProgress,
} from '@mui/material';
import {
  Psychology as PsychologyIcon,
  Search as SearchIcon,
} from '@mui/icons-material';
import { useMutation } from '@tanstack/react-query';
import { apiService } from '../services/api';

const emotions = ['anxiety', 'sadness', 'anger', 'stress', 'fear', 'loneliness'];

const Strategies: React.FC = () => {
  const [selectedEmotion, setSelectedEmotion] = useState('');
  const [customEmotion, setCustomEmotion] = useState('');

  const getStrategiesMutation = useMutation({
    mutationFn: apiService.getCopingStrategies,
    onError: (error) => {
      console.error('Error fetching strategies:', error);
    },
  });

  const handleGetStrategies = (emotion: string) => {
    getStrategiesMutation.mutate({ emotion });
    setSelectedEmotion(emotion);
  };

  const handleCustomEmotion = () => {
    if (customEmotion.trim()) {
      handleGetStrategies(customEmotion.trim());
    }
  };

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Coping Strategies
      </Typography>
      
      <Typography variant="body1" color="text.secondary" paragraph>
        Select an emotion to get personalized coping strategies and techniques to help you manage your feelings.
      </Typography>

      {/* Emotion Selection */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Choose an Emotion
        </Typography>
        
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
          {emotions.map((emotion) => (
            <Chip
              key={emotion}
              label={emotion.charAt(0).toUpperCase() + emotion.slice(1)}
              onClick={() => handleGetStrategies(emotion)}
              variant={selectedEmotion === emotion ? 'filled' : 'outlined'}
              color={selectedEmotion === emotion ? 'primary' : 'default'}
            />
          ))}
        </Box>

        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
          <TextField
            label="Custom emotion"
            value={customEmotion}
            onChange={(e) => setCustomEmotion(e.target.value)}
            placeholder="Enter a specific emotion..."
            sx={{ flexGrow: 1 }}
          />
          <Button
            variant="outlined"
            onClick={handleCustomEmotion}
            disabled={!customEmotion.trim()}
            startIcon={<SearchIcon />}
          >
            Get Strategies
          </Button>
        </Box>
      </Box>

      {/* Strategies Display */}
      {getStrategiesMutation.isPending && (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <CircularProgress />
        </Box>
      )}

      {getStrategiesMutation.isSuccess && getStrategiesMutation.data && (
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <PsychologyIcon sx={{ mr: 1, color: 'primary.main' }} />
              <Typography variant="h5" component="h2">
                Coping Strategies for {getStrategiesMutation.data.emotion.charAt(0).toUpperCase() + getStrategiesMutation.data.emotion.slice(1)}
              </Typography>
            </Box>

            <List>
              {getStrategiesMutation.data.strategies.map((strategy, index) => (
                <ListItem key={index} sx={{ alignItems: 'flex-start' }}>
                  <ListItemIcon>
                    <Typography variant="h6" color="primary">
                      {index + 1}.
                    </Typography>
                  </ListItemIcon>
                  <ListItemText
                    primary={strategy}
                    sx={{ '& .MuiListItemText-primary': { fontSize: '1.1rem' } }}
                  />
                </ListItem>
              ))}
            </List>

            <Alert severity="info" sx={{ mt: 2 }}>
              <Typography variant="body2">
                {getStrategiesMutation.data.disclaimer}
              </Typography>
            </Alert>
          </CardContent>
        </Card>
      )}

      {getStrategiesMutation.isError && (
        <Alert severity="error">
          Failed to load coping strategies. Please try again.
        </Alert>
      )}

      {/* General Tips */}
      <Card sx={{ mt: 4 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            General Wellbeing Tips
          </Typography>
          <List>
            <ListItem>
              <ListItemText
                primary="Practice regular self-care activities"
                secondary="Take time for activities that bring you joy and relaxation"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Maintain social connections"
                secondary="Stay connected with friends, family, or support groups"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Get adequate sleep and nutrition"
                secondary="Physical health significantly impacts mental wellbeing"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Consider professional help when needed"
                secondary="Don't hesitate to seek support from mental health professionals"
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Strategies;
