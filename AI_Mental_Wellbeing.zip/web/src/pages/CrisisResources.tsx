import React from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Alert,
  Button,
  Chip,
} from '@mui/material';
import {
  Emergency as EmergencyIcon,
  Phone as PhoneIcon,
  Message as MessageIcon,
  LocalHospital as HospitalIcon,
} from '@mui/icons-material';
import { useQuery } from '@tanstack/react-query';
import { apiService } from '../services/api';

const CrisisResources: React.FC = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['crisis-resources'],
    queryFn: apiService.getCrisisResources,
  });

  const getIcon = (name: string) => {
    if (name.toLowerCase().includes('text')) return <MessageIcon />;
    if (name.toLowerCase().includes('emergency') || name.toLowerCase().includes('911')) {
      return <EmergencyIcon />;
    }
    if (name.toLowerCase().includes('hospital') || name.toLowerCase().includes('health')) {
      return <HospitalIcon />;
    }
    return <PhoneIcon />;
  };

  const isEmergency = (name: string) => {
    return name.toLowerCase().includes('emergency') || name.toLowerCase().includes('911');
  };

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Crisis Resources
      </Typography>
      
      <Alert severity="warning" sx={{ mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          🚨 If you're in immediate danger, call 911 or your local emergency number right now.
        </Typography>
        <Typography variant="body2">
          These resources are available 24/7 for crisis support and mental health emergencies.
        </Typography>
      </Alert>

      {isLoading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Typography>Loading crisis resources...</Typography>
        </Box>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          Failed to load crisis resources. Please try again or contact emergency services directly.
        </Alert>
      )}

      {data && (
        <>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
            <Chip label="24/7 Available" color="primary" />
            <Chip label="Confidential" color="secondary" />
            <Chip label="Free Support" color="success" />
          </Box>

          <List>
            {data.resources.map((resource, index) => (
              <Card key={index} sx={{ mb: 2 }}>
                <CardContent>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemIcon sx={{ color: isEmergency(resource.name) ? 'error.main' : 'primary.main' }}>
                      {getIcon(resource.name)}
                    </ListItemIcon>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="h6">
                            {resource.name}
                          </Typography>
                          {isEmergency(resource.name) && (
                            <Chip label="EMERGENCY" color="error" size="small" />
                          )}
                        </Box>
                      }
                      secondary={
                        <Box sx={{ mt: 1 }}>
                          <Typography variant="h5" color="primary" sx={{ fontWeight: 'bold' }}>
                            {resource.contact}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {isEmergency(resource.name) 
                              ? 'Call immediately for life-threatening emergencies'
                              : 'Available 24/7 for mental health support and crisis intervention'
                            }
                          </Typography>
                        </Box>
                      }
                    />
                    <Button
                      variant={isEmergency(resource.name) ? 'contained' : 'outlined'}
                      color={isEmergency(resource.name) ? 'error' : 'primary'}
                      href={resource.contact.includes('Text') ? undefined : `tel:${resource.contact.replace(/[^\d]/g, '')}`}
                      sx={{ ml: 2 }}
                    >
                      {resource.contact.includes('Text') ? 'Text Now' : 'Call Now'}
                    </Button>
                  </ListItem>
                </CardContent>
              </Card>
            ))}
          </List>

          <Alert severity="info" sx={{ mt: 3 }}>
            <Typography variant="body2">
              {data.disclaimer}
            </Typography>
          </Alert>
        </>
      )}

      {/* Additional Information */}
      <Card sx={{ mt: 4 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            What to Expect When You Call
          </Typography>
          <List>
            <ListItem>
              <ListItemText
                primary="Trained counselors are available 24/7"
                secondary="You'll speak with someone who understands mental health crises"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Confidential and non-judgmental support"
                secondary="Your conversation is private and you won't be judged"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Immediate crisis intervention"
                secondary="Counselors can help de-escalate crisis situations"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Referrals to local resources"
                secondary="They can connect you with local mental health services"
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>
    </Box>
  );
};

export default CrisisResources;
