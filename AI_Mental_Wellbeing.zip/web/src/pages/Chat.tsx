import React, { useState, useRef, useEffect } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  List,
  ListItem,
  CircularProgress,
  Alert,
  Fade,
  Slide,
  Zoom,
  Avatar,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  Send as SendIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import { useMutation } from '@tanstack/react-query';
import { apiService } from '../services/api';
import type { ChatMessage } from '../types/api';

const Chat: React.FC = () => {
  const [message, setMessage] = useState('');
  const [sessionId, setSessionId] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  // const queryClient = useQueryClient();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: apiService.sendMessage,
    onSuccess: (data) => {
      setIsTyping(false);
      // Add AI response to messages
      const newMessage: ChatMessage = {
        role: 'assistant',
        content: data.response,
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, newMessage]);
      
      // Update session ID if it's new
      if (!sessionId) {
        setSessionId(data.session_id);
      }
    },
    onError: (error) => {
      console.error('Error sending message:', error);
      setIsTyping(false);
    },
  });

  // Clear conversation mutation
  const clearConversationMutation = useMutation({
    mutationFn: apiService.clearConversation,
    onSuccess: () => {
      setMessages([]);
      setSessionId('');
    },
  });

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    // Add user message to UI immediately
    const userMessage: ChatMessage = {
      role: 'user',
      content: message,
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Send to API
    sendMessageMutation.mutate({
      message: message.trim(),
      session_id: sessionId || undefined,
    });

    setMessage('');
  };

  const handleClearConversation = () => {
    if (sessionId) {
      clearConversationMutation.mutate(sessionId);
    } else {
      setMessages([]);
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Box sx={{ 
      height: 'calc(100vh - 120px)', 
      display: 'flex', 
      flexDirection: 'column',
      px: { xs: 1, sm: 2 },
    }}>
      <Fade in timeout={500}>
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          mb: 2,
          flexDirection: { xs: 'column', sm: 'row' },
          gap: 2,
        }}>
          <Typography 
            variant="h4" 
            component="h1"
            sx={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
            }}
          >
            💬 Chat with AI Support
          </Typography>
          <Button
            variant="outlined"
            startIcon={<ClearIcon />}
            onClick={handleClearConversation}
            disabled={messages.length === 0}
            sx={{
              borderRadius: 3,
              textTransform: 'none',
              fontWeight: 500,
            }}
          >
            Clear Chat
          </Button>
        </Box>
      </Fade>

      {/* Messages Area */}
      <Slide direction="up" in timeout={600}>
        <Paper
          elevation={3}
          sx={{
            flexGrow: 1,
            overflow: 'auto',
            p: { xs: 1, sm: 2 },
            mb: 2,
            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
            borderRadius: 3,
            position: 'relative',
            '&::before': {
              content: '""',
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '1px',
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
            },
          }}
        >
        {messages.length === 0 ? (
          <Fade in timeout={800}>
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
                color: 'text.secondary',
                textAlign: 'center',
                px: 2,
              }}
            >
              <Zoom in timeout={1000}>
                <Box sx={{ mb: 3 }}>
                  <Typography variant="h4" sx={{ mb: 2, fontWeight: 600 }}>
                    🧠 Welcome to AI Mental Wellbeing Support
                  </Typography>
                  <Typography variant="body1" sx={{ maxWidth: 600, lineHeight: 1.6 }}>
                    I'm here to provide emotional support and guidance. You can share your thoughts,
                    feelings, or concerns, and I'll do my best to help you with coping strategies
                    and support.
                  </Typography>
                </Box>
              </Zoom>
              <Fade in timeout={1200}>
                <Alert 
                  severity="info" 
                  sx={{ 
                    mt: 2, 
                    maxWidth: 600,
                    borderRadius: 2,
                    '& .MuiAlert-icon': {
                      fontSize: '1.2rem',
                    },
                  }}
                >
                  <Typography variant="body2">
                    <strong>Important:</strong> This AI is for emotional support only. If you're in crisis,
                    please contact emergency services immediately. This is not a replacement for
                    professional mental health care.
                  </Typography>
                </Alert>
              </Fade>
            </Box>
          </Fade>
        ) : (
          <List sx={{ p: 0 }}>
            {messages.map((msg, index) => (
              <Fade in timeout={300} key={index}>
                <ListItem
                  sx={{
                    flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
                    alignItems: 'flex-start',
                    mb: 2,
                    px: { xs: 0, sm: 1 },
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, maxWidth: '85%' }}>
                    <Avatar
                      sx={{
                        width: 32,
                        height: 32,
                        backgroundColor: msg.role === 'user' ? theme.palette.primary.main : theme.palette.secondary.main,
                        fontSize: '0.8rem',
                      }}
                    >
                      {msg.role === 'user' ? '👤' : '🤖'}
                    </Avatar>
                    <Paper
                      elevation={2}
                      sx={{
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: msg.role === 'user' 
                          ? '#1976d2'
                          : '#dc004e',
                        color: 'white',
                        position: 'relative',
                        maxWidth: '100%',
                        wordWrap: 'break-word',
                        '&::before': {
                          content: '""',
                          position: 'absolute',
                          top: 8,
                          [msg.role === 'user' ? 'right' : 'left']: -8,
                          width: 0,
                          height: 0,
                          borderTop: '8px solid transparent',
                          borderBottom: '8px solid transparent',
                          [msg.role === 'user' ? 'borderLeft' : 'borderRight']: `8px solid ${
                            msg.role === 'user' ? '#1976d2' : '#dc004e'
                          }`,
                        },
                      }}
                    >
                      <Typography 
                        variant="body1" 
                        sx={{ 
                          whiteSpace: 'pre-wrap', 
                          lineHeight: 1.5,
                          color: '#ffffff !important',
                          fontWeight: 500,
                          fontSize: '1rem',
                          textShadow: '0 1px 2px rgba(0,0,0,0.3)',
                        }}
                      >
                        {msg.content}
                      </Typography>
                      <Typography
                        variant="caption"
                        sx={{
                          display: 'block',
                          mt: 1,
                          opacity: 1,
                          fontSize: '0.75rem',
                          color: '#ffffff !important',
                          fontWeight: 400,
                          textShadow: '0 1px 2px rgba(0,0,0,0.3)',
                        }}
                      >
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </Typography>
                    </Paper>
                  </Box>
                </ListItem>
              </Fade>
            ))}
            {isTyping && (
              <Fade in timeout={300}>
                <ListItem>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, ml: 5 }}>
                    <Avatar sx={{ width: 32, height: 32, backgroundColor: theme.palette.secondary.main }}>
                      🤖
                    </Avatar>
                    <Paper
                      elevation={1}
                      sx={{
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: theme.palette.grey[100],
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1,
                      }}
                    >
                      <CircularProgress size={16} />
                      <Typography variant="body2" color="text.secondary">
                        AI is thinking...
                      </Typography>
                    </Paper>
                  </Box>
                </ListItem>
              </Fade>
            )}
            <div ref={messagesEndRef} />
          </List>
        )}
        </Paper>
      </Slide>

      {/* Input Area */}
      <Slide direction="up" in timeout={800}>
        <Paper 
          elevation={4} 
          sx={{ 
            p: 2,
            borderRadius: 3,
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            position: 'relative',
            overflow: 'hidden',
            '&::before': {
              content: '""',
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '1px',
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
            },
          }}
        >
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-end' }}>
            <TextField
              fullWidth
              multiline
              maxRows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Share your thoughts or feelings..."
              disabled={sendMessageMutation.isPending}
              variant="outlined"
              sx={{
                '& .MuiOutlinedInput-root': {
                  backgroundColor: 'white',
                  borderRadius: 2,
                  '& .MuiInputBase-input': {
                    color: '#000000 !important',
                    fontWeight: 500,
                    '&::placeholder': {
                      color: '#666666 !important',
                      opacity: 1,
                      fontWeight: 400,
                    },
                  },
                  '&:hover': {
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: theme.palette.primary.main,
                    },
                  },
                  '&.Mui-focused': {
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: theme.palette.primary.main,
                      borderWidth: 2,
                    },
                  },
                },
              }}
            />
            <Button
              variant="contained"
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending}
              sx={{ 
                minWidth: { xs: 80, sm: 100 },
                height: 56,
                borderRadius: 2,
                background: '#1976d2',
                color: '#ffffff !important',
                fontWeight: 600,
                fontSize: '0.9rem',
                textTransform: 'none',
                '&:hover': {
                  background: '#1565c0',
                  transform: 'translateY(-2px)',
                },
                '&:disabled': {
                  background: theme.palette.grey[400],
                  color: '#ffffff !important',
                },
              }}
              startIcon={sendMessageMutation.isPending ? <CircularProgress size={20} color="inherit" /> : <SendIcon />}
            >
              {isMobile ? 'Send' : 'Send'}
            </Button>
          </Box>
        </Paper>
      </Slide>
    </Box>
  );
};

export default Chat;
