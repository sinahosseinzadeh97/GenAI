import React from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Alert,
  Chip,
  Divider,
} from '@mui/material';
import {
  Psychology as PsychologyIcon,
  Security as SecurityIcon,
  Support as SupportIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';

const About: React.FC = () => {
  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        About AI Mental Wellbeing Support
      </Typography>
      
      <Typography variant="body1" color="text.secondary" paragraph>
        This application provides AI-powered mental health support and wellbeing resources
        to help you manage your emotions and find coping strategies during difficult times.
      </Typography>

      {/* Features */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Features
          </Typography>
          <List>
            <ListItem>
              <ListItemIcon>
                <PsychologyIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary="AI-Powered Emotional Support"
                secondary="Get personalized responses and guidance from our AI mental wellbeing agent"
              />
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <SupportIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary="Coping Strategies"
                secondary="Access evidence-based techniques for managing anxiety, sadness, anger, and stress"
              />
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <SecurityIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary="Crisis Resources"
                secondary="Quick access to emergency contacts and mental health helplines"
              />
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <PsychologyIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary="Conversation Memory"
                secondary="Maintain context across your conversation for personalized support"
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>

      {/* Important Disclaimers */}
      <Alert severity="warning" sx={{ mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          <WarningIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Important Disclaimers
        </Typography>
        <Typography variant="body2" component="div">
          <ul style={{ margin: 0, paddingLeft: '20px' }}>
            <li>This AI is for emotional support only and is not a replacement for professional mental health care</li>
            <li>If you're experiencing a mental health crisis, please contact emergency services immediately</li>
            <li>This tool should complement, not replace, professional mental health treatment</li>
            <li>Always consult with qualified mental health professionals for serious concerns</li>
          </ul>
        </Typography>
      </Alert>

      {/* How It Works */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            How It Works
          </Typography>
          <List>
            <ListItem>
              <ListItemText
                primary="1. Start a Conversation"
                secondary="Share your thoughts, feelings, or concerns in the chat interface"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="2. Receive AI Support"
                secondary="Get empathetic responses and practical guidance from our AI agent"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="3. Access Resources"
                secondary="Explore coping strategies and crisis resources tailored to your needs"
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="4. Continue Your Journey"
                secondary="Maintain conversation history for ongoing support and guidance"
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>

      {/* Technology Stack */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Technology
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
            <Chip label="React" color="primary" />
            <Chip label="TypeScript" color="primary" />
            <Chip label="Material-UI" color="primary" />
            <Chip label="FastAPI" color="secondary" />
            <Chip label="OpenAI GPT" color="secondary" />
            <Chip label="Python" color="secondary" />
          </Box>
          <Typography variant="body2" color="text.secondary">
            Built with modern web technologies and powered by OpenAI's advanced language models
            to provide intelligent and compassionate mental health support.
          </Typography>
        </CardContent>
      </Card>

      {/* Contact Information */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Need Help?
          </Typography>
          <Typography variant="body2" paragraph>
            If you're experiencing technical issues or have questions about this application,
            please refer to the crisis resources page for immediate support options.
          </Typography>
          <Divider sx={{ my: 2 }} />
          <Typography variant="body2" color="text.secondary">
            <strong>Remember:</strong> This application is designed to provide emotional support
            and should be used alongside professional mental health care when needed.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default About;
