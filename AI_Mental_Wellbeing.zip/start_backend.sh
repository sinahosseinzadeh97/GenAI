#!/bin/bash
# Start FastAPI backend

echo "🚀 Starting AI Mental Wellbeing Backend..."
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
