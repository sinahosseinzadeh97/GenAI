#!/usr/bin/env python3
"""
AI Mental Wellbeing Agent

A conversational AI agent designed to provide mental health support,
emotional guidance, and wellbeing resources.
"""

import os
import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv
import openai
import streamlit as st

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=getattr(logging, os.getenv('LOG_LEVEL', 'INFO')),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class MentalWellbeingAgent:
    """
    AI Mental Wellbeing Agent that provides emotional support and guidance.
    """
    
    def __init__(self):
        """Initialize the agent with OpenAI client and configuration."""
        self.openai_client = openai.OpenAI(
            api_key=os.getenv('OPENAI_API_KEY')
        )
        self.model = os.getenv('DEFAULT_MODEL', 'gpt-3.5-turbo')
        self.max_tokens = int(os.getenv('MAX_TOKENS', '1000'))
        self.temperature = float(os.getenv('TEMPERATURE', '0.7'))
        
        # System prompt for mental wellbeing support
        self.system_prompt = """
        You are a compassionate AI mental wellbeing agent. Your role is to:
        
        1. Provide emotional support and active listening
        2. Offer evidence-based coping strategies
        3. Suggest mindfulness and relaxation techniques
        4. Help users identify and express their emotions
        5. Provide resources for professional help when appropriate
        6. Maintain a warm, non-judgmental, and supportive tone
        
        Important guidelines:
        - Never provide medical diagnosis or treatment
        - Always encourage professional help for serious mental health concerns
        - Focus on emotional support and practical coping strategies
        - Be empathetic and validate the user's feelings
        - Keep responses concise but meaningful
        - Ask follow-up questions to better understand the user's needs
        
        If a user expresses thoughts of self-harm or suicide, immediately:
        1. Take their concerns seriously
        2. Encourage them to contact emergency services or a crisis hotline
        3. Provide crisis resources
        """
        
        self.conversation_history = []
        
    def add_to_history(self, role: str, content: str):
        """Add a message to conversation history."""
        self.conversation_history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        
    async def get_response(self, user_message: str) -> str:
        """
        Generate a response to the user's message.
        
        Args:
            user_message: The user's input message
            
        Returns:
            AI agent's response
        """
        try:
            # Add user message to history
            self.add_to_history("user", user_message)
            
            # Prepare messages for OpenAI API
            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend(self.conversation_history[-10:])  # Keep last 10 messages for context
            
            # Call OpenAI API
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            ai_response = response.choices[0].message.content
            
            # Add AI response to history
            self.add_to_history("assistant", ai_response)
            
            logger.info(f"Generated response for user message: {user_message[:50]}...")
            return ai_response
            
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return "I apologize, but I'm experiencing some technical difficulties. Please try again in a moment, or consider reaching out to a mental health professional if you need immediate support."
    
    def get_coping_strategies(self, emotion: str) -> List[str]:
        """
        Provide coping strategies for specific emotions.
        
        Args:
            emotion: The emotion the user is experiencing
            
        Returns:
            List of coping strategies
        """
        strategies = {
            "anxiety": [
                "Practice deep breathing exercises (4-7-8 technique)",
                "Try progressive muscle relaxation",
                "Use grounding techniques (5-4-3-2-1 method)",
                "Engage in gentle physical activity",
                "Practice mindfulness meditation"
            ],
            "sadness": [
                "Allow yourself to feel and express your emotions",
                "Connect with supportive friends or family",
                "Engage in activities you used to enjoy",
                "Practice self-compassion and self-care",
                "Consider journaling your thoughts and feelings"
            ],
            "anger": [
                "Take a break and step away from the situation",
                "Practice deep breathing or counting to 10",
                "Engage in physical exercise to release tension",
                "Use 'I' statements to express your feelings",
                "Try relaxation techniques like meditation"
            ],
            "stress": [
                "Break tasks into smaller, manageable steps",
                "Practice time management and prioritization",
                "Engage in regular physical exercise",
                "Maintain a healthy sleep schedule",
                "Practice relaxation techniques"
            ]
        }
        
        return strategies.get(emotion.lower(), [
            "Practice deep breathing exercises",
            "Engage in mindfulness or meditation",
            "Connect with supportive people",
            "Engage in physical activity",
            "Practice self-care activities"
        ])
    
    def get_crisis_resources(self) -> Dict[str, str]:
        """
        Provide crisis resources and emergency contacts.
        
        Returns:
            Dictionary of crisis resources
        """
        return {
            "National Suicide Prevention Lifeline": "988",
            "Crisis Text Line": "Text HOME to 741741",
            "National Alliance on Mental Illness (NAMI)": "1-800-950-NAMI (6264)",
            "Emergency Services": "911",
            "SAMHSA National Helpline": "1-800-662-4357"
        }
    
    def clear_conversation(self):
        """Clear the conversation history."""
        self.conversation_history = []
        logger.info("Conversation history cleared")

def main():
    """Main function to run the Streamlit app."""
    st.set_page_config(
        page_title="AI Mental Wellbeing Agent",
        page_icon="🧠",
        layout="wide"
    )
    
    st.title("🧠 AI Mental Wellbeing Agent")
    st.markdown("A compassionate AI companion for emotional support and mental wellbeing guidance.")
    
    # Initialize the agent
    if 'agent' not in st.session_state:
        st.session_state.agent = MentalWellbeingAgent()
    
    # Sidebar with resources
    with st.sidebar:
        st.header("📚 Resources")
        
        if st.button("Coping Strategies"):
            emotion = st.selectbox(
                "Select an emotion:",
                ["anxiety", "sadness", "anger", "stress", "other"]
            )
            strategies = st.session_state.agent.get_coping_strategies(emotion)
            st.write("**Coping Strategies:**")
            for i, strategy in enumerate(strategies, 1):
                st.write(f"{i}. {strategy}")
        
        if st.button("Crisis Resources"):
            resources = st.session_state.agent.get_crisis_resources()
            st.write("**Crisis Resources:**")
            for name, contact in resources.items():
                st.write(f"**{name}:** {contact}")
        
        if st.button("Clear Conversation"):
            st.session_state.agent.clear_conversation()
            st.rerun()
    
    # Main chat interface
    st.header("💬 Chat with Your AI Companion")
    
    # Display conversation history
    for message in st.session_state.agent.conversation_history:
        if message["role"] == "user":
            st.write(f"**You:** {message['content']}")
        else:
            st.write(f"**AI:** {message['content']}")
    
    # Chat input
    user_input = st.text_input(
        "Share what's on your mind...",
        placeholder="I'm feeling anxious about work..."
    )
    
    if st.button("Send") and user_input:
        with st.spinner("Thinking..."):
            # Get AI response
            response = asyncio.run(st.session_state.agent.get_response(user_input))
            st.rerun()
    
    # Footer
    st.markdown("---")
    st.markdown(
        """
        **Important Disclaimer:** This AI agent is not a replacement for professional mental health care. 
        If you're experiencing a mental health crisis, please contact emergency services or a mental health professional immediately.
        """
    )

if __name__ == "__main__":
    # Check if OpenAI API key is set
    if not os.getenv('OPENAI_API_KEY'):
        print("⚠️  Warning: OPENAI_API_KEY not found in environment variables.")
        print("Please set your OpenAI API key in the .env file.")
    
    main()