#!/bin/bash
# Start Telegram bot

echo "🤖 Starting AI Mental Wellbeing Telegram Bot..."
python telegram_bot_api.py
