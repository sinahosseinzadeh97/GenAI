#!/usr/bin/env python3
"""
Telegram AI Mental Wellbeing Bot - API Version

A Telegram bot that provides mental health support using FastAPI backend.
"""

import os
import json
import logging
import asyncio
import aiohttp
from datetime import datetime
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=getattr(logging, os.getenv('LOG_LEVEL', 'INFO')),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class MentalWellbeingBotAPI:
    """
    Telegram bot for AI Mental Wellbeing support using FastAPI backend.
    """
    
    def __init__(self):
        """Initialize the bot with API configuration."""
        self.api_base_url = os.getenv('API_BASE_URL', 'http://localhost:8000')
        self.session = None
        
    async def get_session(self):
        """Get or create aiohttp session."""
        if self.session is None:
            self.session = aiohttp.ClientSession()
        return self.session
    
    async def close_session(self):
        """Close aiohttp session."""
        if self.session:
            await self.session.close()
            self.session = None
    
    async def call_api(self, endpoint: str, method: str = 'GET', data: Optional[Dict] = None) -> Dict:
        """Call FastAPI endpoint."""
        session = await self.get_session()
        url = f"{self.api_base_url}{endpoint}"
        
        try:
            if method.upper() == 'GET':
                async with session.get(url) as response:
                    return await response.json()
            elif method.upper() == 'POST':
                async with session.post(url, json=data) as response:
                    return await response.json()
            elif method.upper() == 'DELETE':
                async with session.delete(url) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"API call failed: {str(e)}")
            raise
    
    async def get_response(self, user_message: str, user_id: int) -> tuple[str, bool]:
        """
        Get AI response from FastAPI backend.
        
        Args:
            user_message: The user's input message
            user_id: Telegram user ID for session tracking
            
        Returns:
            Tuple of (AI response, crisis_detected)
        """
        try:
            response_data = await self.call_api(
                '/api/v1/chat',
                'POST',
                {
                    'message': user_message,
                    'user_id': str(user_id)
                }
            )
            
            return response_data['response'], response_data['crisis_detected']
            
        except Exception as e:
            logger.error(f"Error getting response for user {user_id}: {str(e)}")
            return "I apologize, but I'm experiencing some technical difficulties. Please try again in a moment, or consider reaching out to a mental health professional if you need immediate support.", False
    
    async def get_coping_strategies(self, emotion: str) -> List[str]:
        """Get coping strategies from FastAPI backend."""
        try:
            response_data = await self.call_api(
                '/api/v1/strategies',
                'POST',
                {'emotion': emotion}
            )
            return response_data['strategies']
        except Exception as e:
            logger.error(f"Error getting coping strategies: {str(e)}")
            return ["I'm sorry, I couldn't retrieve coping strategies right now. Please try again later."]
    
    async def get_crisis_resources(self) -> Dict[str, str]:
        """Get crisis resources from FastAPI backend."""
        try:
            response_data = await self.call_api('/api/v1/crisis')
            return {resource['name']: resource['contact'] for resource in response_data['resources']}
        except Exception as e:
            logger.error(f"Error getting crisis resources: {str(e)}")
            return {
                "Emergency Services": "911",
                "Crisis Text Line": "Text HOME to 741741"
            }
    
    async def clear_user_conversation(self, user_id: int):
        """Clear conversation history for a specific user."""
        try:
            await self.call_api(f'/api/v1/chat/{user_id}', 'DELETE')
            logger.info(f"Conversation history cleared for user {user_id}")
        except Exception as e:
            logger.error(f"Error clearing conversation for user {user_id}: {str(e)}")

# Initialize the bot
bot = MentalWellbeingBotAPI()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    welcome_message = """
🧠 *Welcome to AI Mental Wellbeing Bot*

I'm here to provide emotional support and mental wellbeing guidance. I can help you with:

• Emotional support and active listening
• Coping strategies for different emotions
• Mindfulness and relaxation techniques
• Crisis resources when needed

Use the buttons below to get started, or simply type your message to begin chatting.
"""
    
    keyboard = [
        [InlineKeyboardButton("📚 Coping Strategies", callback_data="coping_strategies")],
        [InlineKeyboardButton("🚨 Crisis Resources", callback_data="crisis_resources")],
        [InlineKeyboardButton("💬 Start Chatting", callback_data="start_chat")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(welcome_message, parse_mode='Markdown', reply_markup=reply_markup)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command."""
    help_text = """
🤖 *AI Mental Wellbeing Bot Commands:*

/start - Welcome message and main menu
/help - Show this help message
/clear - Clear your conversation history
/strategies - Get coping strategies for emotions
/crisis - Show crisis resources and emergency contacts

*How to use:*
• Type any message to start chatting with the AI
• Use the inline buttons for quick access to features
• The bot remembers your conversation for context

*Remember:* If you're in crisis, please contact emergency services immediately.
"""
    
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def clear_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /clear command."""
    user_id = update.effective_user.id
    await bot.clear_user_conversation(user_id)
    await update.message.reply_text("✅ Your conversation history has been cleared.")

async def strategies_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /strategies command."""
    keyboard = [
        [InlineKeyboardButton("😰 Anxiety", callback_data="emotion_anxiety")],
        [InlineKeyboardButton("😢 Sadness", callback_data="emotion_sadness")],
        [InlineKeyboardButton("😠 Anger", callback_data="emotion_anger")],
        [InlineKeyboardButton("😰 Stress", callback_data="emotion_stress")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Choose an emotion to get coping strategies:",
        reply_markup=reply_markup
    )

async def crisis_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /crisis command."""
    resources = await bot.get_crisis_resources()
    crisis_text = "🚨 *Crisis Resources & Emergency Contacts:*\n\n"
    
    for name, contact in resources.items():
        crisis_text += f"*{name}:* {contact}\n"
    
    crisis_text += "\n*If you're in immediate danger, call 911 or your local emergency number.*"
    
    await update.message.reply_text(crisis_text, parse_mode='Markdown')

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle regular text messages."""
    user_message = update.message.text
    user_id = update.effective_user.id
    
    # Get AI response
    response, crisis_detected = await bot.get_response(user_message, user_id)
    
    # Add crisis warning if detected
    if crisis_detected:
        response += "\n\n🚨 *If you're in crisis, please contact emergency services immediately.*"
    
    # Add disclaimer
    response += "\n\n⚠️ *This AI is for emotional support only. If you need professional help, please contact a mental health professional.*"
    
    await update.message.reply_text(response, parse_mode='Markdown')

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries from inline keyboards."""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "main_menu":
        keyboard = [
            [InlineKeyboardButton("📚 Coping Strategies", callback_data="coping_strategies")],
            [InlineKeyboardButton("🚨 Crisis Resources", callback_data="crisis_resources")],
            [InlineKeyboardButton("💬 Start Chatting", callback_data="start_chat")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "Choose an option:",
            reply_markup=reply_markup
        )
    
    elif data == "coping_strategies":
        keyboard = [
            [InlineKeyboardButton("😰 Anxiety", callback_data="emotion_anxiety")],
            [InlineKeyboardButton("😢 Sadness", callback_data="emotion_sadness")],
            [InlineKeyboardButton("😠 Anger", callback_data="emotion_anger")],
            [InlineKeyboardButton("😰 Stress", callback_data="emotion_stress")],
            [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "Choose an emotion to get coping strategies:",
            reply_markup=reply_markup
        )
    
    elif data == "crisis_resources":
        resources = await bot.get_crisis_resources()
        crisis_text = "🚨 *Crisis Resources & Emergency Contacts:*\n\n"
        
        for name, contact in resources.items():
            crisis_text += f"*{name}:* {contact}\n"
        
        crisis_text += "\n*If you're in immediate danger, call 911 or your local emergency number.*"
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(crisis_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    elif data.startswith("emotion_"):
        emotion = data.replace("emotion_", "")
        strategies = await bot.get_coping_strategies(emotion)
        
        strategy_text = f"*Coping Strategies for {emotion.title()}:*\n\n"
        for i, strategy in enumerate(strategies, 1):
            strategy_text += f"{i}. {strategy}\n"
        
        keyboard = [
            [InlineKeyboardButton("🔙 Back to Strategies", callback_data="coping_strategies")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(strategy_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    elif data == "start_chat":
        keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "💬 *Start Chatting*\n\nJust type your message and I'll respond with emotional support and guidance.\n\n*Remember:* If you're in crisis, please contact emergency services immediately.",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )

def main():
    """Main function to run the bot."""
    telegram_token = os.getenv('TELEGRAM_BOT_TOKEN')
    api_url = os.getenv('API_BASE_URL', 'http://localhost:8000')
    
    if not telegram_token:
        logger.error("TELEGRAM_BOT_TOKEN not found in environment variables")
        print("❌ Error: TELEGRAM_BOT_TOKEN not found in .env file")
        return
    
    print(f"🤖 Starting Telegram bot...")
    print(f"🔗 API URL: {api_url}")
    
    # Create application
    application = Application.builder().token(telegram_token).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("clear", clear_command))
    application.add_handler(CommandHandler("strategies", strategies_command))
    application.add_handler(CommandHandler("crisis", crisis_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(CallbackQueryHandler(handle_callback))
    
    # Start the bot
    print("✅ Bot started successfully!")
    print("Press Ctrl+C to stop the bot")
    
    try:
        application.run_polling()
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user")
    finally:
        # Close API session
        asyncio.run(bot.close_session())

if __name__ == '__main__':
    main()
