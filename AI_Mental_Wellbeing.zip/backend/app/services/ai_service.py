"""
AI service for mental wellbeing support.
"""

import os
import logging
from typing import Dict, List, Optional
from datetime import datetime
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)


class AIService:
    """AI service for mental wellbeing support."""
    
    def __init__(self):
        """Initialize the AI service with OpenAI client and configuration."""
        self.openai_client = openai.OpenAI(
            api_key=os.getenv('OPENAI_API_KEY')
        )
        self.model = os.getenv('DEFAULT_MODEL', 'gpt-3.5-turbo')
        self.max_tokens = int(os.getenv('MAX_TOKENS', '1000'))
        self.temperature = float(os.getenv('TEMPERATURE', '0.7'))
        
        # System prompt for mental wellbeing support
        self.system_prompt = """
        You are a compassionate AI mental wellbeing agent. Your role is to:
        
        1. Provide emotional support and active listening
        2. Offer evidence-based coping strategies
        3. Suggest mindfulness and relaxation techniques
        4. Help users identify and express their emotions
        5. Provide gentle guidance and encouragement
        
        Guidelines:
        - Always be empathetic and non-judgmental
        - Focus on emotional support and practical coping strategies
        - Keep responses concise but meaningful (under 2000 characters)
        - Ask follow-up questions to better understand the user's needs
        
        If a user expresses thoughts of self-harm or suicide, immediately:
        1. Take their concerns seriously
        2. Encourage them to contact emergency services or a crisis hotline
        3. Provide crisis resources
        """
        
        # In-memory conversation storage (in production, use Redis or database)
        self.conversations: Dict[str, List[Dict]] = {}
    
    def get_conversation_history(self, session_id: str) -> List[Dict]:
        """Get conversation history for a session."""
        return self.conversations.get(session_id, [])
    
    def add_to_history(self, session_id: str, role: str, content: str):
        """Add a message to conversation history."""
        if session_id not in self.conversations:
            self.conversations[session_id] = []
        
        self.conversations[session_id].append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep only last 10 messages for context
        if len(self.conversations[session_id]) > 10:
            self.conversations[session_id].pop(0)
    
    def clear_conversation(self, session_id: str):
        """Clear conversation history for a session."""
        if session_id in self.conversations:
            del self.conversations[session_id]
        logger.info(f"Conversation history cleared for session {session_id}")
    
    async def get_response(self, message: str, session_id: str) -> tuple[str, bool]:
        """
        Generate a response to the user's message.
        
        Args:
            message: The user's input message
            session_id: Session ID for conversation continuity
            
        Returns:
            Tuple of (AI response, crisis_detected)
        """
        try:
            # Add user message to history
            self.add_to_history(session_id, "user", message)
            
            # Check for crisis indicators
            crisis_detected = self._detect_crisis(message)
            
            # Prepare messages for OpenAI API
            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend(self.get_conversation_history(session_id))
            
            # Call OpenAI API
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            ai_response = response.choices[0].message.content
            
            # Add AI response to history
            self.add_to_history(session_id, "assistant", ai_response)
            
            logger.info(f"Generated response for session {session_id}: {message[:50]}...")
            return ai_response, crisis_detected
            
        except Exception as e:
            logger.error(f"Error generating response for session {session_id}: {str(e)}")
            return "I apologize, but I'm experiencing some technical difficulties. Please try again in a moment, or consider reaching out to a mental health professional if you need immediate support.", False
    
    def _detect_crisis(self, message: str) -> bool:
        """Detect crisis indicators in the message."""
        crisis_keywords = [
            "suicide", "kill myself", "end my life", "not worth living",
            "want to die", "hurt myself", "self harm", "cut myself",
            "overdose", "jump off", "hang myself", "shoot myself"
        ]
        
        message_lower = message.lower()
        return any(keyword in message_lower for keyword in crisis_keywords)
    
    def get_coping_strategies(self, emotion: str) -> List[str]:
        """Provide coping strategies for specific emotions."""
        strategies = {
            "anxiety": [
                "Practice deep breathing exercises (4-7-8 technique)",
                "Try progressive muscle relaxation",
                "Use grounding techniques (5-4-3-2-1 method)",
                "Engage in gentle physical activity",
                "Practice mindfulness meditation"
            ],
            "sadness": [
                "Allow yourself to feel and express your emotions",
                "Connect with supportive friends or family",
                "Engage in activities you used to enjoy",
                "Practice self-compassion and self-care",
                "Consider journaling your thoughts and feelings"
            ],
            "anger": [
                "Take a break and step away from the situation",
                "Practice deep breathing or counting to 10",
                "Engage in physical exercise to release tension",
                "Use 'I' statements to express your feelings",
                "Try relaxation techniques like meditation"
            ],
            "stress": [
                "Break tasks into smaller, manageable steps",
                "Practice time management and prioritization",
                "Engage in regular physical exercise",
                "Maintain a healthy sleep schedule",
                "Practice relaxation techniques"
            ]
        }
        
        return strategies.get(emotion.lower(), [
            "Practice deep breathing exercises",
            "Engage in mindfulness or meditation",
            "Connect with supportive people",
            "Engage in physical activity",
            "Practice self-care activities"
        ])
    
    def get_crisis_resources(self) -> List[Dict[str, str]]:
        """Provide crisis resources and emergency contacts."""
        return [
            {"name": "National Suicide Prevention Lifeline", "contact": "988"},
            {"name": "Crisis Text Line", "contact": "Text HOME to 741741"},
            {"name": "National Alliance on Mental Illness (NAMI)", "contact": "1-800-950-NAMI (6264)"},
            {"name": "Emergency Services", "contact": "911"},
            {"name": "SAMHSA National Helpline", "contact": "1-800-662-4357"}
        ]
