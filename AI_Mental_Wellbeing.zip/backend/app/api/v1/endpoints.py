"""
API endpoints for mental wellbeing support.
"""

import uuid
import logging
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse

from app.models.schemas import (
    ChatRequest, ChatResponse, CopingStrategyRequest, CopingStrategyResponse,
    CrisisResponse, HealthResponse, ErrorResponse
)
from app.services.ai_service import AIService

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()

# Initialize AI service
ai_service = AIService()


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(status="healthy")


@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Chat endpoint for AI mental wellbeing support."""
    try:
        # Generate session ID if not provided
        session_id = request.session_id or str(uuid.uuid4())
        
        # Get AI response
        response, crisis_detected = await ai_service.get_response(
            request.message, session_id
        )
        
        # Create disclaimer
        disclaimer = (
            "⚠️ **Important:** This AI is for emotional support only. "
            "If you're in crisis, please contact emergency services immediately. "
            "This is not a replacement for professional mental health care."
        )
        
        return ChatResponse(
            response=response,
            session_id=session_id,
            crisis_detected=crisis_detected,
            disclaimer=disclaimer
        )
        
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/strategies", response_model=CopingStrategyResponse)
async def get_coping_strategies(request: CopingStrategyRequest):
    """Get coping strategies for specific emotions."""
    try:
        strategies = ai_service.get_coping_strategies(request.emotion)
        
        disclaimer = (
            "💡 **Note:** These are general coping strategies. "
            "If you're experiencing severe distress, please consider "
            "speaking with a mental health professional."
        )
        
        return CopingStrategyResponse(
            emotion=request.emotion,
            strategies=strategies,
            disclaimer=disclaimer
        )
        
    except Exception as e:
        logger.error(f"Error in strategies endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/crisis", response_model=CrisisResponse)
async def get_crisis_resources():
    """Get crisis resources and emergency contacts."""
    try:
        resources_data = ai_service.get_crisis_resources()
        
        # Convert to CrisisResource objects
        from app.models.schemas import CrisisResource
        resources = [CrisisResource(name=r["name"], contact=r["contact"]) for r in resources_data]
        
        disclaimer = (
            "🚨 **Emergency:** If you're in immediate danger, call 911 or your local emergency number. "
            "These resources are available 24/7 for crisis support."
        )
        
        return CrisisResponse(
            resources=resources,
            disclaimer=disclaimer
        )
        
    except Exception as e:
        logger.error(f"Error in crisis endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/chat/{session_id}")
async def clear_conversation(session_id: str):
    """Clear conversation history for a session."""
    try:
        ai_service.clear_conversation(session_id)
        return {"message": "Conversation history cleared successfully"}
        
    except Exception as e:
        logger.error(f"Error clearing conversation: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")
