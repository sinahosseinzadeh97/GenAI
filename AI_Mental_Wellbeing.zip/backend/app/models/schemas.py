"""
Pydantic models for API requests and responses.
"""

from typing import List, Dict, Optional
from pydantic import BaseModel, Field
from datetime import datetime


class ChatMessage(BaseModel):
    """Individual chat message."""
    role: str = Field(..., description="Message role: user, assistant, or system")
    content: str = Field(..., description="Message content")
    timestamp: datetime = Field(default_factory=datetime.now, description="Message timestamp")


class ChatRequest(BaseModel):
    """Request for chat endpoint."""
    message: str = Field(..., description="User message", min_length=1, max_length=2000)
    session_id: Optional[str] = Field(None, description="Session ID for conversation continuity")
    user_id: Optional[str] = Field(None, description="User ID for conversation tracking")


class ChatResponse(BaseModel):
    """Response from chat endpoint."""
    response: str = Field(..., description="AI agent response")
    session_id: str = Field(..., description="Session ID for conversation continuity")
    crisis_detected: bool = Field(default=False, description="Whether crisis situation was detected")
    disclaimer: str = Field(..., description="Safety disclaimer")


class CopingStrategyRequest(BaseModel):
    """Request for coping strategies."""
    emotion: str = Field(..., description="Emotion to get strategies for", min_length=1)


class CopingStrategyResponse(BaseModel):
    """Response with coping strategies."""
    emotion: str = Field(..., description="Requested emotion")
    strategies: List[str] = Field(..., description="List of coping strategies")
    disclaimer: str = Field(..., description="Safety disclaimer")


class CrisisResource(BaseModel):
    """Individual crisis resource."""
    name: str = Field(..., description="Resource name")
    contact: str = Field(..., description="Contact information")


class CrisisResponse(BaseModel):
    """Response with crisis resources."""
    resources: List[CrisisResource] = Field(..., description="List of crisis resources")
    disclaimer: str = Field(..., description="Emergency disclaimer")


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = Field(..., description="Service status")
    timestamp: datetime = Field(default_factory=datetime.now, description="Check timestamp")
    version: str = Field(default="1.0.0", description="API version")


class ErrorResponse(BaseModel):
    """Error response."""
    error: str = Field(..., description="Error message")
    detail: Optional[str] = Field(None, description="Additional error details")
