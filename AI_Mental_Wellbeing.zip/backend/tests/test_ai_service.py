"""
Tests for AI service.
"""

import pytest
from unittest.mock import patch, MagicMock
from app.services.ai_service import AIService


class TestAIService:
    """Test AI service functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        with patch.dict('os.environ', {
            'OPENAI_API_KEY': 'test-key',
            'DEFAULT_MODEL': 'gpt-3.5-turbo',
            'MAX_TOKENS': '1000',
            'TEMPERATURE': '0.7'
        }):
            with patch('app.services.ai_service.openai.OpenAI') as mock_openai:
                self.ai_service = AIService()
                self.mock_openai = mock_openai
    
    def test_get_conversation_history_empty(self):
        """Test getting empty conversation history."""
        history = self.ai_service.get_conversation_history("test-session")
        assert history == []
    
    def test_add_to_history(self):
        """Test adding messages to history."""
        session_id = "test-session"
        self.ai_service.add_to_history(session_id, "user", "Hello")
        self.ai_service.add_to_history(session_id, "assistant", "Hi there")
        
        history = self.ai_service.get_conversation_history(session_id)
        assert len(history) == 2
        assert history[0]["role"] == "user"
        assert history[0]["content"] == "Hello"
        assert history[1]["role"] == "assistant"
        assert history[1]["content"] == "Hi there"
    
    def test_clear_conversation(self):
        """Test clearing conversation history."""
        session_id = "test-session"
        self.ai_service.add_to_history(session_id, "user", "Hello")
        self.ai_service.clear_conversation(session_id)
        
        history = self.ai_service.get_conversation_history(session_id)
        assert history == []
    
    def test_detect_crisis_positive(self):
        """Test crisis detection with positive cases."""
        crisis_messages = [
            "I want to kill myself",
            "I'm thinking about suicide",
            "I want to end my life",
            "I want to hurt myself",
            "I want to die"
        ]
        
        for message in crisis_messages:
            assert self.ai_service._detect_crisis(message) is True
    
    def test_detect_crisis_negative(self):
        """Test crisis detection with negative cases."""
        normal_messages = [
            "I'm feeling sad today",
            "I need help with anxiety",
            "I'm stressed about work",
            "I want to talk to someone"
        ]
        
        for message in normal_messages:
            assert self.ai_service._detect_crisis(message) is False
    
    def test_get_coping_strategies_anxiety(self):
        """Test getting coping strategies for anxiety."""
        strategies = self.ai_service.get_coping_strategies("anxiety")
        assert len(strategies) > 0
        assert "deep breathing" in strategies[0].lower()
    
    def test_get_coping_strategies_sadness(self):
        """Test getting coping strategies for sadness."""
        strategies = self.ai_service.get_coping_strategies("sadness")
        assert len(strategies) > 0
        assert "emotions" in strategies[0].lower()
    
    def test_get_coping_strategies_unknown(self):
        """Test getting coping strategies for unknown emotion."""
        strategies = self.ai_service.get_coping_strategies("unknown")
        assert len(strategies) > 0
        assert "breathing" in strategies[0].lower()
    
    def test_get_crisis_resources(self):
        """Test getting crisis resources."""
        resources = self.ai_service.get_crisis_resources()
        assert len(resources) > 0
        
        # Check that we have expected resources
        resource_names = [r["name"] for r in resources]
        assert "Emergency Services" in resource_names
        assert "Crisis Text Line" in resource_names
    
    @pytest.mark.asyncio
    async def test_get_response_success(self):
        """Test successful response generation."""
        # Mock OpenAI response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = "Test AI response"
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        self.mock_openai.return_value = mock_client
        
        response, crisis_detected = await self.ai_service.get_response(
            "Hello", "test-session"
        )
        
        assert response == "Test AI response"
        assert crisis_detected is False
        
        # Check that message was added to history
        history = self.ai_service.get_conversation_history("test-session")
        assert len(history) == 2  # user message + AI response
        assert history[0]["role"] == "user"
        assert history[1]["role"] == "assistant"
    
    @pytest.mark.asyncio
    async def test_get_response_crisis_detected(self):
        """Test response generation with crisis detection."""
        # Mock OpenAI response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = "Crisis response"
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        self.mock_openai.return_value = mock_client
        
        response, crisis_detected = await self.ai_service.get_response(
            "I want to kill myself", "test-session"
        )
        
        assert response == "Crisis response"
        assert crisis_detected is True
    
    @pytest.mark.asyncio
    async def test_get_response_error(self):
        """Test response generation with error."""
        # Mock OpenAI error
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API Error")
        self.mock_openai.return_value = mock_client
        
        response, crisis_detected = await self.ai_service.get_response(
            "Hello", "test-session"
        )
        
        assert "technical difficulties" in response.lower()
        assert crisis_detected is False
