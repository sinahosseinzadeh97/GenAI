"""
Tests for API endpoints.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock

from app.main import app

client = TestClient(app)


class TestHealthEndpoint:
    """Test health check endpoint."""
    
    def test_health_check(self):
        """Test health endpoint returns 200."""
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert "version" in data


class TestChatEndpoint:
    """Test chat endpoint."""
    
    @patch('app.api.v1.endpoints.ai_service')
    def test_chat_success(self, mock_ai_service):
        """Test successful chat request."""
        async def mock_get_response(message, session_id):
            return ("Test response", False)
        mock_ai_service.get_response = mock_get_response
        
        response = client.post(
            "/api/v1/chat",
            json={"message": "Hello, I need help"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["response"] == "Test response"
        assert data["crisis_detected"] is False
        assert "session_id" in data
        assert "disclaimer" in data
    
    @patch('app.api.v1.endpoints.ai_service')
    def test_chat_crisis_detected(self, mock_ai_service):
        """Test chat with crisis detection."""
        async def mock_get_response(message, session_id):
            return ("Crisis response", True)
        mock_ai_service.get_response = mock_get_response
        
        response = client.post(
            "/api/v1/chat",
            json={"message": "I want to hurt myself"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["crisis_detected"] is True
    
    def test_chat_empty_message(self):
        """Test chat with empty message."""
        response = client.post(
            "/api/v1/chat",
            json={"message": ""}
        )
        
        assert response.status_code == 422  # Validation error
    
    def test_chat_missing_message(self):
        """Test chat with missing message."""
        response = client.post(
            "/api/v1/chat",
            json={}
        )
        
        assert response.status_code == 422  # Validation error


class TestStrategiesEndpoint:
    """Test coping strategies endpoint."""
    
    @patch('app.api.v1.endpoints.ai_service')
    def test_get_strategies_success(self, mock_ai_service):
        """Test successful strategies request."""
        mock_ai_service.get_coping_strategies.return_value = [
            "Deep breathing",
            "Meditation"
        ]
        
        response = client.post(
            "/api/v1/strategies",
            json={"emotion": "anxiety"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["emotion"] == "anxiety"
        assert len(data["strategies"]) == 2
        assert "disclaimer" in data
    
    def test_get_strategies_empty_emotion(self):
        """Test strategies with empty emotion."""
        response = client.post(
            "/api/v1/strategies",
            json={"emotion": ""}
        )
        
        assert response.status_code == 422  # Validation error


class TestCrisisEndpoint:
    """Test crisis resources endpoint."""
    
    @patch('app.api.v1.endpoints.ai_service')
    def test_get_crisis_resources(self, mock_ai_service):
        """Test crisis resources request."""
        mock_ai_service.get_crisis_resources.return_value = [
            {"name": "Test Line", "contact": "123-456-7890"}
        ]
        
        response = client.get("/api/v1/crisis")
        
        assert response.status_code == 200
        data = response.json()
        assert len(data["resources"]) == 1
        assert data["resources"][0]["name"] == "Test Line"
        assert "disclaimer" in data


class TestClearConversationEndpoint:
    """Test clear conversation endpoint."""
    
    @patch('app.api.v1.endpoints.ai_service')
    def test_clear_conversation(self, mock_ai_service):
        """Test clearing conversation."""
        mock_ai_service.clear_conversation.return_value = None
        
        response = client.delete("/api/v1/chat/test-session-id")
        
        assert response.status_code == 200
        data = response.json()
        assert data["message"] == "Conversation history cleared successfully"
