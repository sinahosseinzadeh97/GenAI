import{v as o}from"./2.B2AoQPnG.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.6b7WW5Kp.js.map
