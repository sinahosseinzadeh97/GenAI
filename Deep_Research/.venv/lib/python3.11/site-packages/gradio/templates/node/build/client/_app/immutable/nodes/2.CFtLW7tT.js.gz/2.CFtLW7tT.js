import{Z as e,_ as n}from"../chunks/2.B2AoQPnG.js";export{e as component,n as universal};
//# sourceMappingURL=2.CFtLW7tT.js.map
