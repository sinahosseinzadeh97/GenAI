import{_ as s}from"./mermaid.core.CKP5SxPy.js";var t,e=(t=class{constructor(i){this.init=i,this.records=this.init()}reset(){this.records=this.init()}},s(t,"ImperativeState"),t);export{e as I};
//# sourceMappingURL=chunk-66XRIAFR.CBOGlNn4.js.map
