import{G as a,f as G}from"./mermaid-parser.core.DezFW7Qm.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-YCYPL57B.Dh_-Z4hO.js.map
