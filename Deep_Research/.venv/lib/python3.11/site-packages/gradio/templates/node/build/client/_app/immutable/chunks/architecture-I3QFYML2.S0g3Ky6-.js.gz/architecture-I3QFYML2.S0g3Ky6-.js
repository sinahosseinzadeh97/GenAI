import{A as c,e as t}from"./mermaid-parser.core.DezFW7Qm.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-I3QFYML2.S0g3Ky6-.js.map
