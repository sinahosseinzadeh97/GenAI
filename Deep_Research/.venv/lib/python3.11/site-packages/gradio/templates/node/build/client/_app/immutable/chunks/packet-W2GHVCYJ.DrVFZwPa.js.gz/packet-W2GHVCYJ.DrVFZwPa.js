import{P as c,a as r}from"./mermaid-parser.core.DezFW7Qm.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.DrVFZwPa.js.map
